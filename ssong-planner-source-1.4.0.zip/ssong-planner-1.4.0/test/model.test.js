const {test}=require('node:test');const assert=require('node:assert/strict');const {due,dateKey}=require('../src/model');
const task={id:'1',date:'2026-10-23',start:'09:00',end:'10:00',status:'planned'};
test('local date key',()=>assert.equal(dateKey(new Date(2026,9,23,0,1)),'2026-10-23'));
test('no early notification',()=>assert.deepEqual(due([task],new Date(2026,9,23,8,59)),[]));
test('start notification',()=>assert.deepEqual(due([task],new Date(2026,9,23,9,0)),[{id:'1',kind:'start'}]));
test('late startup prioritizes end',()=>assert.deepEqual(due([task],new Date(2026,9,23,11,0)),[{id:'1',kind:'end'}]));
test('completed and held tasks stay silent',()=>{for(const status of ['done','hold'])assert.deepEqual(due([{...task,status}],new Date(2026,9,23,11)),[])});
test('notification is not repeated',()=>assert.deepEqual(due([{...task,startNotified:true,endNotified:true}],new Date(2026,9,23,11)),[]));
test('other dates stay silent',()=>assert.deepEqual(due([task],new Date(2026,9,24,11)),[]));
const model=require('../src/model');
const overnight={...task,start:'20:00',end:'01:00',endNextDay:true};
test('overnight end crosses midnight and appears on both days',()=>{assert.equal(model.bounds(overnight).end.getDate(),24);assert.equal(model.onDate(overnight,'2026-10-24'),true);assert.equal(model.onDate(overnight,'2026-10-25'),false);assert.equal(model.validTask(overnight),false);assert.equal(model.validTask({...overnight,text:'야간 일정'}),true)});
test('overnight start does not trigger end at 20:00',()=>assert.deepEqual(due([overnight],new Date(2026,9,23,20)),[{id:'1',kind:'start'}]));
test('overnight warning at 00:50 and end at 01:00',()=>{const t={...overnight,startNotified:true};assert.deepEqual(due([t],new Date(2026,9,24,0,49)),[]);assert.deepEqual(due([t],new Date(2026,9,24,0,50)),[{id:'1',kind:'warning'}]);assert.deepEqual(due([{...t,warningNotified:true}],new Date(2026,9,24,0,59)),[]);assert.deepEqual(due([t],new Date(2026,9,24,1)),[{id:'1',kind:'end'}])});
test('explicit next-day later clock time and month/year boundaries',()=>{for(const [date,expected] of [['2026-10-31','2026-11-01'],['2026-12-31','2027-01-01']]){const t={...overnight,date,end:'22:00'};assert.equal(dateKey(model.bounds(t).end),expected)}});
test('same clock requires next-day, invalid clock is rejected',()=>{assert.equal(model.validTask({...task,text:'작업',end:'09:00'}),false);assert.equal(model.validTask({...task,text:'작업',end:'09:00',endNextDay:true}),true);for(const start of ['24:00','12:60','garbage'])assert.equal(model.validTask({...task,text:'작업',start}),false)});
const reminder={id:'r',text:'물 마시기',interval:5,count:5,fired:0,nextAt:300000,active:true};
test('repeat alarm first fires after full interval',()=>{assert.deepEqual(model.reminderDue([reminder],299999),[]);assert.deepEqual(model.reminderDue([reminder],300000),[{id:'r',kind:'reminder',number:1,nextAt:600000}])});
test('repeat alarm respects count and never repeats after final occurrence',()=>{let r={...reminder};for(let n=1;n<=5;n++){const [event]=model.reminderDue([r],n*300000);assert.equal(event.number,n);r={...r,fired:event.number,nextAt:event.nextAt}}assert.deepEqual(model.reminderDue([r],1800000),[])});
test('sleep recovery coalesces missed occurrences and retains schedule',()=>{const [e]=model.reminderDue([reminder],950000);assert.equal(e.number,3);assert.equal(e.nextAt,1200000);const [last]=model.reminderDue([reminder],99999999);assert.equal(last.number,5)});
test('one-minute single alarm and cancelled alarm',()=>{const r={...reminder,interval:1,count:1,nextAt:60000};assert.equal(model.reminderDue([r],60000)[0].number,1);assert.deepEqual(model.reminderDue([{...r,active:false}],60000),[])});
test('repeat alarm validates interval/count boundaries',()=>{assert.equal(model.validReminder(reminder),true);for(const patch of [{interval:0},{interval:1441},{count:0},{count:6},{interval:1.5},{count:1.2}])assert.equal(model.validReminder({...reminder,...patch}),false)});
test('infinite reminders survive reload, continue past five and coalesce sleep',()=>{
 let r=JSON.parse(JSON.stringify({...reminder,count:null}));assert.equal(model.validReminder(r),true);
 for(let n=1;n<=12;n++){const [event]=model.reminderDue([r],n*300000);assert.equal(event.number,n);r={...r,fired:event.number,nextAt:event.nextAt};assert.equal(model.validReminder(r),true)}
 const [event]=model.reminderDue([r],6000000);assert.equal(event.number,20);assert.equal(event.nextAt,6300000);
 assert.deepEqual(model.reminderDue([{...r,active:false}],6000000),[]);
});
test('daily quote stays stable within a local day and changes across month/year boundaries',()=>{
 for(const [year,month,day] of [[2026,9,24],[2026,9,31],[2026,11,31]]){
 const a=model.dailyQuote(new Date(year,month,day,0,1)),b=model.dailyQuote(new Date(year,month,day,23,59)),next=model.dailyQuote(new Date(year,month,day+1));
 assert.deepEqual(a,b);assert.notDeepEqual(a,next);assert.ok(a.every(t=>typeof t==='string'&&t.length));
 }
});
test('weekly review starts on Monday across year boundaries',()=>{assert.equal(model.weekStart(new Date(2027,0,3)), '2026-12-28');assert.equal(model.weekStart(new Date(2027,0,4)),'2027-01-04')});
test('completion timing and extended deadlines are recorded without inventing legacy timestamps',()=>{
 const base={...task,text:'원고'};let active=model.recordTask(base,{...base,status:'active'},new Date(2026,9,23,9).getTime());
 let extended=model.recordTask(active,{...active,end:'11:00'},new Date(2026,9,23,9,30).getTime());
 const complete=model.recordTask(extended,{...extended,status:'done'},new Date(2026,9,23,11).getTime());
 const report=model.weeklyReview([complete],'2026-10-19',new Date(2026,9,24).getTime());assert.equal(report.done.length,1);assert.deepEqual(report.delayed[0].reasons,['마감 후 완료','마감 연장','소요 시간 초과']);
 const legacy=model.recordTask({...base,status:'done'},{...base,text:'옛 기록',status:'done'},Date.now());assert.equal(legacy.completedAt,null);assert.equal(model.weeklyReview([legacy],'2026-10-19').delayed.length,0);
 const reopened=model.recordTask(complete,{...complete,status:'active'},Date.now());assert.equal(reopened.completedAt,null);
});
test('weekly review includes overdue and overnight tasks but excludes unrelated weeks',()=>{
 const old={...task,text:'미완료'},other={...task,id:'2',date:'2026-09-01',text:'다른 주'};
 const report=model.weeklyReview([old,other],'2026-10-19',new Date(2026,9,24).getTime());assert.equal(report.delayed.length,1);assert.deepEqual(report.delayed[0].reasons,['마감 초과']);
 const night={...old,date:'2026-10-25',start:'23:00',end:'01:00',endNextDay:true};assert.equal(model.weeklyReview([night],'2026-10-26',new Date(2026,9,27).getTime()).delayed.length,1);
});
test('active time excludes time spent on hold and ignores supplied timing fields',()=>{
 const base={...task,text:'작업'};const active=model.recordTask(base,{...base,status:'active',elapsedMs:99999999},1000);assert.equal(active.elapsedMs,0);
 const held=model.recordTask(active,{...active,status:'hold'},61000);assert.equal(held.elapsedMs,60000);
 const resumed=model.recordTask(held,{...held,status:'active'},361000);assert.equal(resumed.elapsedMs,60000);
 const done=model.recordTask(resumed,{...resumed,status:'done'},421000);assert.equal(done.elapsedMs,120000);assert.equal(done.activeSince,null);
});
