const {test}=require('node:test'),assert=require('node:assert/strict'),holidays=require('../src/holidays');
test('Korean holidays include corrected three-day lunar spans, substitutes and 2026 election',()=>{
 const days=holidays(2026);for(const date of ['2026-02-16','2026-02-17','2026-02-18'])assert.equal(days[date],'설날');assert.equal(days['2026-02-19'],undefined);
 for(const date of ['2026-09-24','2026-09-25','2026-09-26'])assert.equal(days[date],'추석');
 assert.match(days['2026-03-02'],/대체공휴일/);assert.match(days['2026-08-17'],/대체공휴일/);assert.match(days['2026-10-05'],/대체공휴일/);assert.match(days['2026-06-03'],/선거/);assert.equal(days['2026-10-04'],undefined);
});
test('holiday year input is bounded',()=>{for(const year of [null,'2026',1899,2101,2026.1])assert.throws(()=>holidays(year));assert.ok(holidays(2027)['2027-01-01'])});
