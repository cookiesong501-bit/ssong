/* Windows installer build. On Linux, extract NSIS's intermediate uninstaller
 * with electron-builder's own reader instead of running it under Wine.
 * The reader is the builder's existing macOS fallback. No tool verification,
 * signing configuration or dependency files are changed by this adapter.
 */
const {build,Platform,Arch}=require('electron-builder');
const path=require('node:path');
const fs=require('node:fs/promises');
const target=process.argv.includes('--portable')?'portable':'nsis';
if(process.platform==='linux'&&target==='nsis'){
 const {NsisTarget}=require('app-builder-lib/out/targets/nsis/NsisTarget');
 const {nsisTemplatesDir,UninstallerReader}=require('app-builder-lib/out/targets/nsis/nsisUtil');
 NsisTarget.prototype.computeScriptAndSignUninstaller=async function(defines,commands,installerPath,sharedHeader,archs){
  if(await this.packager.getResource(this.options.script,'installer.nsi'))throw Error('The Linux extractor supports only the standard NSIS installer template.');
  const script=await fs.readFile(path.join(nsisTemplatesDir,'installer.nsi'),'utf8');
  const uninstallerPath=path.join(this.outDir,`${path.basename(installerPath,'exe')}__uninstaller.exe`);
  defines.BUILD_UNINSTALLER=null;
  defines.UNINSTALLER_OUT_FILE=path.win32.join('Z:',uninstallerPath);
  await this.executeMakensis(defines,commands,sharedHeader+await this.computeFinalScript(script,false,archs));
  await UninstallerReader.exec(installerPath,uninstallerPath);
  await this.packager.signIf(uninstallerPath);
  delete defines.BUILD_UNINSTALLER;
  defines.UNINSTALLER_OUT_FILE=uninstallerPath;
  return {script,isCustomScript:false};
 };
}
build({projectDir:path.resolve(__dirname,'..'),targets:Platform.WINDOWS.createTarget(target,Arch.x64),publish:'never'})
 .then(files=>console.log('Built Windows package:',files.join('\n')))
 .catch(error=>{console.error(error);process.exitCode=1});
