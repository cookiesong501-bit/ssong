const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {JSDOM}=require('jsdom');
const model=require('../src/model');
async function screen(saved,seedTasks=[],seedReminders=[]){
 const html=fs.readFileSync('src/index.html','utf8');
 const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://todo.local/'}),w=dom.window;
 if(saved!==undefined)w.localStorage.setItem('ssong-diary-v1',saved);
 const store={tasks:JSON.parse(JSON.stringify(seedTasks)),reminders:JSON.parse(JSON.stringify(seedReminders))};
 w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};
 w.todo={holidays:async year=>require('../src/holidays')(year),load:async()=>({...JSON.parse(JSON.stringify(store)),platform:'win32',packaged:true,autoStart:true}),save:async data=>{assert.ok(data.every(model.validTask));store.tasks=JSON.parse(JSON.stringify(data.map(t=>model.recordTask(store.tasks.find(old=>old.id===t.id),t,Date.now()))));return store.tasks},onChange(){},onReminders(){},autoStart:async b=>b,addReminder:async data=>{store.reminders.push({...data,id:'r',fired:0});return store.reminders},removeReminder:async()=>{store.reminders=[];return []}};
 for(const file of ['model.js','time-picker.js','app.js','diary.js']){const s=w.document.createElement('script');s.textContent=fs.readFileSync('src/'+file,'utf8');w.document.body.append(s)}
 await new Promise(r=>setImmediate(r));
 return {w,store,$:id=>w.document.getElementById(id),close:()=>w.close()};
}
test('hour and minute wheels stop at both bounds',async()=>{const ui=await screen();try{for(const [selector,min,max] of [['#start-picker input[aria-label="시작 시"]',1,12],['#start-picker input[aria-label="시작 분"]',0,59]]){const n=ui.w.document.querySelector(selector);n.focus();n.value=max;n.dispatchEvent(new ui.w.WheelEvent('wheel',{deltaY:-1,cancelable:true}));assert.equal(Number(n.value),max);n.value=min;n.dispatchEvent(new ui.w.WheelEvent('wheel',{deltaY:1,cancelable:true}));assert.equal(Number(n.value),min)}}finally{ui.close()}});
test('AM/PM conversion and overnight save survive editing',async()=>{const ui=await screen();try{ui.$('text').value='밤 작업';ui.$('start').value='20:00';ui.$('end').value='01:00';ui.w.TimePickers.start();ui.w.TimePickers.end();assert.equal(ui.w.document.querySelector('#start-picker select').value,'pm');assert.equal(ui.w.document.querySelector('#end-picker input').value,'01');await ui.$('add-form').onsubmit({preventDefault(){}});assert.equal(ui.store.tasks[0].endNextDay,true);assert.equal(ui.store.tasks[0].end,'01:00');assert.match(ui.$('tasks').textContent,/다음 날 01:00/);ui.$('tasks').querySelector('button').click();assert.equal(ui.$('end-next-day'),null);await ui.$('add-form').onsubmit({preventDefault(){}});assert.equal(ui.store.tasks.length,1);assert.equal(ui.store.tasks[0].start,'20:00');const next=new Date(ui.store.tasks[0].date+'T12:00:00');next.setDate(next.getDate()+1);const key=model.dateKey(next);ui.w.eval(`selected='${key}';render()`);assert.match(ui.$('tasks').textContent,/전날 20:00/);assert.doesNotMatch(ui.$('tasks').textContent,/다음 날 01:00/)}finally{ui.close()}});
test('time controls correctly distinguish midnight and noon',async()=>{const ui=await screen();try{const p=ui.w.document.querySelector('#start-picker select'),h=ui.w.document.querySelector('#start-picker input');h.value='12';p.value='am';p.dispatchEvent(new ui.w.Event('change'));assert.equal(ui.$('start').value,'00:00');p.value='pm';p.dispatchEvent(new ui.w.Event('change'));assert.equal(ui.$('start').value,'12:00')}finally{ui.close()}});
test('independent alarm form sends interval/count and supports deletion',async()=>{const ui=await screen();try{ui.$('reminder-text').value='스트레칭';ui.$('reminder-interval').value='1';ui.$('reminder-count').value='5';await ui.$('reminder-form').onsubmit({preventDefault(){}});assert.equal(ui.store.reminders[0].interval,1);assert.match(ui.$('reminders').textContent,/1분마다 0\/5회/);await ui.$('reminders').querySelector('button').onclick();assert.equal(ui.store.reminders.length,0);assert.equal(ui.$('reminders').children.length,0)}finally{ui.close()}});
test('friendly popups show correct choices and request bell playback',async()=>{
 for(const kind of ['start','warning','end','reminder']){
  const dom=new JSDOM(fs.readFileSync('src/alert.html','utf8'),{runScripts:'dangerously',url:'https://todo.local/'}),w=dom.window;let handler,played=0,answer;
  w.HTMLMediaElement.prototype.play=function(){played++;return Promise.resolve()};
  w.todo={onAlert:fn=>handler=fn,answer:data=>answer=data,soundFallback(){}};
  const s=w.document.createElement('script');s.textContent=fs.readFileSync('src/alert.js','utf8');w.document.body.append(s);
  handler({task:{id:'1',text:'물 마시기',interval:5,count:5},kind,number:2});
  assert.equal(played,1);assert.match(w.document.getElementById('task').textContent,/물 마시기/);
  if(kind==='warning')assert.match(w.document.getElementById('title').textContent,/10분/);
  if(kind==='reminder'){assert.match(w.document.getElementById('title').textContent,/5분 간격 · 2번째/);assert.equal(w.document.querySelectorAll('#actions button').length,1)}
  w.document.querySelector('#actions button').click();assert.equal(answer.id,'1');assert.equal(answer.status,kind==='reminder'?'ack':kind==='start'?'active':'done');w.close();
 }
});
test('custom title buttons dispatch window actions and update restore label',()=>{
 const dom=new JSDOM(fs.readFileSync('src/index.html','utf8'),{runScripts:'dangerously'}),w=dom.window;let state;const sent=[];
 w.todo={windowControl:action=>sent.push(action),onWindowState:fn=>state=fn};
 const s=w.document.createElement('script');s.textContent=fs.readFileSync('src/window-controls.js','utf8');w.document.body.append(s);
 for(const action of ['minimize','maximize','close'])w.document.querySelector(`[data-window="${action}"]`).click();
 assert.deepEqual(sent,['minimize','maximize','close']);state(true);assert.equal(w.document.getElementById('maximize-window').getAttribute('aria-label'),'이전 크기로');state(false);assert.equal(w.document.getElementById('maximize-window').title,'최대화');w.close();
});
test('diary tabs switch panels with mouse and keyboard and infinite alarm submits null',async()=>{
 const ui=await screen();try{
 assert.equal(ui.$('calendar-view').hidden,false);assert.equal(ui.$('reminder-view').hidden,true);
 ui.$('reminder-tab').click();assert.equal(ui.$('calendar-view').hidden,true);assert.equal(ui.$('reminder-tab').getAttribute('aria-selected'),'true');
 ui.$('reminder-tab').dispatchEvent(new ui.w.KeyboardEvent('keydown',{key:'Home',bubbles:true}));assert.equal(ui.$('calendar-view').hidden,false);assert.equal(ui.w.document.activeElement.id,'calendar-tab');
 ui.$('reminder-count').value='infinite';await ui.$('reminder-form').onsubmit({preventDefault(){}});assert.equal(ui.store.reminders[0].count,null);assert.match(ui.$('reminders').textContent,/無限|무한 반복/);assert.doesNotMatch(ui.$('reminders').textContent,/null|완료/);
 assert.ok(ui.$('daily-quote').textContent.length>0);
 }finally{ui.close()}
});
test('eight tasks fit on one page and a ninth remains reachable',async()=>{
 const ui=await screen();try{
 for(let n=0;n<9;n++){ui.$('text').value='일정 '+n;await ui.$('add-form').onsubmit({preventDefault(){}})}
 assert.equal(ui.$('tasks').children.length,8);assert.equal(ui.$('tasks').querySelectorAll('.task-status').length,8);assert.equal(ui.$('tasks').querySelector('.task').children.length,5);
 ui.$('task-pages').querySelectorAll('button')[1].click();assert.match(ui.$('tasks').textContent,/일정 8/);ui.$('today').click();assert.match(ui.$('tasks').textContent,/일정 0/);
 }finally{ui.close()}
});
test('six tabs follow requested order and daily quote is beside the calendar',async()=>{const ui=await screen();try{assert.deepEqual([...ui.w.document.querySelectorAll('[role=tab]')].map(e=>e.textContent),['기본 일정','주간 회고록','연간 계획','월간 계획','알람','메모']);assert.equal(ui.$('daily-quote').closest('aside').querySelector('#calendar'),ui.$('calendar'));assert.match(ui.w.document.title,/쏭 플래너/)}finally{ui.close()}});
test('drag paints multiple monthly cells without erasing legacy text and plan titles edit inline',async()=>{
 const date=model.dateKey(new Date()),saved=JSON.stringify({plans:[{id:'p',title:'예전 계획',color:'green',cells:{[date]:{text:'이전 글씨',color:'blue',status:'review'}}}],memos:[]});const ui=await screen(saved);try{
 const buttons=ui.$('plan-grid').querySelectorAll('tbody tr:first-child td button');buttons[3].dispatchEvent(new ui.w.MouseEvent('pointerdown',{button:0,bubbles:true}));buttons[7].dispatchEvent(new ui.w.MouseEvent('pointerenter',{bubbles:true}));ui.w.document.dispatchEvent(new ui.w.MouseEvent('pointerup',{bubbles:true}));assert.equal(ui.$('plan-dialog').open,true);assert.match(ui.$('plan-date').textContent,/5칸/);
 ui.w.document.querySelector('[name=plan-color][value=red]').checked=true;ui.$('plan-cell-form').dispatchEvent(new ui.w.Event('submit',{cancelable:true}));let value=JSON.parse(ui.w.localStorage.getItem('ssong-diary-v1'));assert.equal(Object.values(value.plans[0].cells).filter(c=>c.color==='red').length,5);assert.equal(value.plans[0].cells[date].text,'이전 글씨');
 assert.equal(ui.$('plan-grid').querySelector('tbody td button.blue')?.textContent||'','');
 const name=ui.$('plan-grid').querySelector('.plan-title-input');name.value='수정 계획';name.dispatchEvent(new ui.w.Event('change'));assert.equal(JSON.parse(ui.w.localStorage.getItem('ssong-diary-v1')).plans[0].title,'수정 계획');
 ui.$('plan-title').value='추가 계획';ui.$('plan-form').dispatchEvent(new ui.w.Event('submit',{cancelable:true}));assert.equal(JSON.parse(ui.w.localStorage.getItem('ssong-diary-v1')).plans.length,2);
 assert.equal(ui.$('plan-grid').querySelectorAll('thead small').length,0);assert.equal(ui.$('plan-grid').querySelector('tbody td button').textContent,'');
 }finally{ui.close()}
});
test('annual 4x3 board has 72 inputs, saves by year and survives reload',async()=>{let saved;const ui=await screen();try{assert.equal(ui.$('year-grid').children.length,12);const inputs=ui.$('year-grid').querySelectorAll('input');assert.equal(inputs.length,72);inputs[0].value='새로운 시작';inputs[0].dispatchEvent(new ui.w.Event('input'));ui.$('year-next').click();assert.equal(ui.$('year-grid').querySelector('input').value,'');ui.$('year-prev').click();assert.equal(ui.$('year-grid').querySelector('input').value,'새로운 시작');saved=ui.w.localStorage.getItem('ssong-diary-v1')}finally{ui.close()}const loaded=await screen(saved);try{assert.equal(loaded.$('year-grid').querySelector('input').value,'새로운 시작')}finally{loaded.close()}});
test('weekly calendar selects seven-day weeks and stores independent improvements',async()=>{const day=model.dateKey(),done={id:'done',date:day,start:'08:00',end:'09:00',text:'완료 업무',status:'done'},late={id:'late',date:day,start:'00:00',end:'00:01',text:'지연 업무',status:'planned'};const ui=await screen(undefined,[done,late]);try{assert.equal(ui.$('review-calendar').querySelectorAll('button').length,6);assert.equal(ui.$('review-calendar').querySelector('button').children.length,7);assert.match(ui.$('review-done').textContent,/완료 업무/);assert.match(ui.$('review-done').textContent,/완료 시각 미기록/);assert.match(ui.$('review-late').textContent,/지연 업무/);ui.$('review-note').value='다음 주는 일찍 시작';ui.$('review-note').dispatchEvent(new ui.w.Event('input'));const first=ui.$('review-calendar').querySelector('button');first.click();if(!ui.$('review-range').textContent.startsWith(model.weekStart()))assert.equal(ui.$('review-note').value,'');ui.$('review-today').click();assert.equal(ui.$('review-note').value,'다음 주는 일찍 시작')}finally{ui.close()}});
test('all alarms are visible without pagination',async()=>{const seed=Array.from({length:12},(_,i)=>({id:String(i),text:'알람 '+i,interval:5,count:null,fired:0,active:true,nextAt:Date.now()+300000}));const ui=await screen(undefined,[],seed);try{assert.equal(ui.$('reminders').children.length,12);assert.equal(ui.$('reminder-pages'),null)}finally{ui.close()}});
test('sticky memos migrate old notes, save inline and filter by category',async()=>{let saved;const ui=await screen(JSON.stringify({plans:[],memos:[{id:'old',title:'예전 제목',body:'예전 내용'}]}));try{assert.match(ui.$('memo-board').querySelector('.memo-body').value,/예전 내용/);ui.$('memo-new').click();assert.equal(ui.$('memo-board').children.length,2);const card=ui.$('memo-board').firstChild;card.querySelector('.memo-title').value='아이디어';card.querySelector('.memo-body').value='<b>새 생각</b>';card.querySelector('.memo-body').dispatchEvent(new ui.w.Event('input'));card.querySelector('.memo-category').value='업무';card.querySelector('.memo-category').dispatchEvent(new ui.w.Event('change'));ui.$('memo-filter').value='업무';ui.$('memo-filter').dispatchEvent(new ui.w.Event('change'));assert.equal(ui.$('memo-board').children.length,1);assert.equal(ui.$('memo-board').querySelector('.memo-body').value,'<b>새 생각</b>');assert.equal(ui.$('memo-board').querySelector('b'),null);saved=ui.w.localStorage.getItem('ssong-diary-v1')}finally{ui.close()}const loaded=await screen(saved);try{assert.equal(loaded.$('memo-board').children.length,2);assert.equal(loaded.$('memo-board').querySelector('.memo-title').value,'아이디어');loaded.w.confirm=()=>true;loaded.$('memo-board').querySelector('.mini').click();assert.equal(JSON.parse(loaded.w.localStorage.getItem('ssong-diary-v1')).memos.length,1)}finally{loaded.close()}});
test('invalid diary remains protected and is not overwritten',async()=>{const ui=await screen('{bad');try{assert.match(ui.$('diary-message').textContent,/기존 기록 보호/);ui.$('memo-new').click();assert.equal(ui.w.localStorage.getItem('ssong-diary-v1'),'{bad')}finally{ui.close()}});
test('custom holidays persist and color the monthly header',async()=>{const ui=await screen();try{ui.$('holiday-add').click();ui.$('holiday-date').value=model.dateKey();ui.$('holiday-name').value='나의 휴일';ui.$('holiday-form').dispatchEvent(new ui.w.Event('submit',{cancelable:true}));assert.equal(ui.$('plan-grid').querySelector(`th[data-date="${model.dateKey()}"]`).classList.contains('holiday'),true);assert.equal(JSON.parse(ui.w.localStorage.getItem('ssong-diary-v1')).holidays[model.dateKey()],'나의 휴일')}finally{ui.close()}});
test('clearing old monthly color preserves previous writing through a reload',async()=>{
 const date=model.dateKey(),seed={plans:[{id:'old',title:'기존 계획',color:'green',cells:{[date]:{text:'보관할 이전 기록',color:'blue',status:'review'}}}],memos:[]};let saved;
 const ui=await screen(JSON.stringify(seed));try{const button=[...ui.$('plan-grid').querySelectorAll('button[data-cell]')].find(b=>JSON.parse(b.dataset.cell)[1]===date);assert.match(button.title,/보관할 이전 기록/);button.click();ui.$('plan-cell-clear').click();saved=ui.w.localStorage.getItem('ssong-diary-v1');const old=JSON.parse(saved).plans[0].cells[date];assert.equal(old.text,'보관할 이전 기록');assert.equal(old.status,'review');assert.equal(old.unpainted,true)}finally{ui.close()}
 const loaded=await screen(saved);try{const button=[...loaded.$('plan-grid').querySelectorAll('button[data-cell]')].find(b=>JSON.parse(b.dataset.cell)[1]===date);assert.match(button.title,/보관할 이전 기록/);assert.equal(button.classList.contains('blue'),false)}finally{loaded.close()}
});
test('calendar shows four tasks in chronological order and counts the rest exactly',async()=>{
 const day=model.dateKey(),seed=Array.from({length:8},(_,i)=>({id:String(i),text:'작업 '+i,date:day,start:`${String(16-i).padStart(2,'0')}:00`,end:'18:00',status:'planned'}));const ui=await screen(undefined,seed);try{
 const cell=ui.$('calendar').querySelector('.selected');assert.equal(cell.getAttribute('aria-pressed'),'true');assert.equal(cell.querySelectorAll('.schedule').length,4);assert.match(cell.querySelector('.schedule').textContent,/작업 7/);assert.equal(cell.querySelector('.more').textContent,'+4개');assert.match(cell.title,/작업 0/);
 }finally{ui.close()}
});
